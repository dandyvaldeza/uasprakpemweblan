<?php
include_once('MPerpustakaan.php');
	class Form
	{
		var $fields = array();
		var $title;
		var $action;
		var $submit = "Input";
		var $jumField = 0;

		function displayForm(){
			echo"<meta charset='utf-8' />
				<meta name='viewport' content='width=device-width, initial-scale=1.0' />
				<title>Free Bootstrap Admin Template : Binary Admin</title>
				<!-- BOOTSTRAP STYLES-->
				<link href='assets/css/bootstrap.css' rel='stylesheet' />
				<!-- FONTAWESOME STYLES-->
				<link href='assets/css/font-awesome.css' rel='stylesheet' />
				<!-- CUSTOM STYLES-->
				<link href='assets/css/custom.css' rel='stylesheet' />
				<!-- GOOGLE FONTS-->
				<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />";
			echo "<h2>".$this->title."</h2>";
			echo "<form action= '".$this->action."' method='post' enctype='multipart/form-data'>";
			for($i=0;$i<$this->jumField;$i++) {
				if($this->fields[$i]['type'] == 'textarea'){
					echo"<div class='form-group'>
						<label>".$this->fields[$i]['label']."</label>";
					echo"<textarea placeholder='deskripsi mengenai buku' class='form-control' name='".$this->fields[$i]['name']."'>".$this->fields[$i]['value']."</textarea></div>";
				}else
					if($this->fields[$i]['type']=='checkbox'){
						echo"<div class='form-group'>
						<label>".$this->fields[$i]['label']."</label>";
							foreach ($this->fields[$i]['option'] as $option => $value){
								if($this->fields[$i]['value'] = $option){
								 	echo"<div class='custom-control custom-checkbox my-1 mr-sm-2'><input type='checkbox' value='".$option."' name='".$this->fields[$i]['name']."'>";
								 	echo"$value</input></div>";
								 }
							}
						echo"</div>";
				}else 
					if($this->fields[$i]['type']=='radio'){
						echo"<div class='form-group'>
						<label>".$this->fields[$i]['label']."</label><br>";
						echo"<input type='radio' name='".$this->fields[$i]['name']."' 
							value = '".$this->fields[$i]['value1']."'>".$this->fields[$i]['value1']."<br>";
						echo"<input type='radio' name='".$this->fields[$i]['name']."' 
							value = '".$this->fields[$i]['value2']."'>".$this->fields[$i]['value2']."</div>";
				}
				else
					if ($this->fields[$i]['type'] == 'select'){
						echo"<div class='form-group'>
							<label>".$this->fields[$i]['label']."</label>";
						echo"<select class='form-control' name='".$this->fields[$i]['name']."'>";
						foreach($this->fields[$i]['value'] as $value){
							echo "<option value='".$value['value']."'>".$value['text']."</option>";
						}
						echo "</select></div>";
				}else{
						echo "<div class='form-group'>
							<label>".$this->fields[$i]['label']."</label>";
						echo "<input class='form-control' type = '".$this->fields[$i]['type']."' name = '".$this->fields[$i]['name']."'";
						if(!empty($this->fields[$i]['option'])){
							foreach($this->fields[$i]['option'] as $atribute => $nilai){
								echo $atribute."='".$nilai."'";
							}
						}
						echo "value='".$this->fields[$i]['value']."'></div>";
					}
			}
			echo"<button name='submit_button' class='btn btn-primary'>".$this->submit."</button>";
			echo"</form>";
		}

		function addField($name, $label, $type = 'text', $value = '', $option = array()){
			$this->fields[$this->jumField]['name']=$name;	
			$this->fields[$this->jumField]['label']=$label;
			$this->fields[$this->jumField]['type']=$type;
			$this->fields[$this->jumField]['value']=$value;
			$this->fields[$this->jumField]['option']=$option;
			$this->jumField++;
		}
 
		function addRadio($name,$label,$type='radio',$value1='value1',$value2='value2')
		{
			$this->fields[$this->jumField]['name']=$name;
			$this->fields[$this->jumField]['label']=$label;
			$this->fields[$this->jumField]['type']=$type;
			$this->fields[$this->jumField]['value1']=$value1;
			$this->fields[$this->jumField]['value2']=$value2;
			$this->jumField++;
		}
		
		function addTextArea($name, $label, $type = 'textarea', $value = ''){
			$this->fields[$this->jumField]['name']=$name;
			$this->fields[$this->jumField]['label']=$label;
			$this->fields[$this->jumField]['type']=$type;
			$this->fields[$this->jumField]['value']=$value;
			$this->jumField++;
		}
 
		function addSelect($name, $label, $type = 'select', $value = array()){
			$this->fields[$this->jumField]['name']=$name;
			$this->fields[$this->jumField]['label']=$label;
			$this->fields[$this->jumField]['type']=$type;
			$this->fields[$this->jumField]['value']=$value;
			$this->jumField++;
		}
		
		function addCheckbox($name,$label, $value='', $option=array()){
			$this->fields[$this->jumField]['name']=$name;
			$this->fields[$this->jumField]['label']=$label;
			$this->fields[$this->jumField]['type']="checkbox";
			$this->fields[$this->jumField]['value']=$value;
			$this->fields[$this->jumField]['option']=$option;
			$this->jumField++;
		}
		
		public function terimaForm(){
			for($i=0;$i<$this->jumField;$i++)
			{
				$this->fields[$i]['value']=$_POST[$this->fields[$i]['name']];
			}
		}
		
		public function cetakForm(){
			for($i=0;$i<$this->jumField;$i++)
			{
				echo"".$this->fields[$i]['label']."
				".$this->fields[$i]['value']."</br>";
			}
		}
		
		public function kirimform(){
			return $this->fields;
		}
		
		public function inputForm(){
			$buku = new Form('','SUBMIT','Form Input Data Mahasiswa');
			$buku->addField('id_buku','Id Buku','text','',array('required' => 'required'));
			$buku->addField('tanggal_buku_masuk','Tanggal Buku Masuk','date','',array('required' => 'required'));
			$buku->addField('judul_buku','Judul Buku','text','',array('required' => 'required'));
			$buku->addField('pengarang','Pengarang','text','',array('required' => 'required'));
			$buku->addField('tahun_terbit','Tahun Penerbitan','text','',array('required' => 'required'));
			$buku->addField('penerbit','Penerbit','text','',array('required' => 'required'));
			$buku->addSelect('kota_terbit','Kota Penerbitan','select',array(
														array('value' => 'Jakarta', 'text' => 'Jakarta'),
														array('value' => 'Bandung', 'text' => 'Bandung'),
														array('value' => 'Surabaya', 'text' => 'Surabaya'),
														array('value' => 'Solo', 'text' => 'Solo'),
														array('value' => 'Yogyakarta', 'text' => 'Yogyakarta'),
														array('value' => 'Banjarmasin', 'text' => 'Banjarmasin'),
														array('value' => 'Lainnya', 'text' => 'Lainnya'),
													));
			$genrebuku = array('Fantasy'=>'Fantasy','Religi'=>'Religi','Horror'=>'Horror', 'Education'=>'Education', 'Lainnya'=>'Lainnya');
			$buku->addCheckbox('genre_buku','Genre',' ',$genrebuku);
			$buku->addRadio('jenis_buku','Jenis Buku : ','radio','Lokal','Terjemahan');
			$buku->addTextArea('deskripsi','deskripsi');
			$buku->addField('status_buku','','hidden','Tersedia');
			
			if(!isset($_POST['submit_button']))
			{
				$buku->displayForm();
		
			}else
			{
				$buku->terimaForm();
				$buku->cetakForm();
			}
		}
		
	}