<?php
include_once('MPerpustakaan.php');
class CBuku {
	
	var $id_buku;
	var $tanggal_buku_masuk;
	var $judul_buku;
	var $pengarang;
	var $tahun_terbit;
	var $penerbit;
	var $kota_terbit;
	var $genre_buku;
	var $genre;
	var $hasil;
	var $jenis_buku;
	var $deskripsi;
	var $status_buku;
 
	public function __construct($id_buku='', $tanggal_buku_masuk='', 
							$judul_buku='', $pengarang='', $tahun_terbit='', 
							$penerbit='', $kota_terbit='', $genre_buku='', $jenis_buku='', 
							$deskripsi='', $status_buku='') {
		$this->id_buku=$id_buku;
		$this->tanggal_buku_masuk=$tanggal_buku_masuk;
		$this->judul_buku=$judul_buku;
		$this->pengarang=$pengarang;
		$this->tahun_terbit=$tahun_terbit;
		$this->penerbit=$penerbit;
		$this->kota_terbit=$kota_terbit;
		$this->genre_buku=$genre_buku;
		$this->jenis_buku=$jenis_buku;
		$this->deskripsi=$deskripsi;
		$this->status_buku=$status_buku;
	}
	
	public function cetakDataBuku(){
		$data="<table class='table table-bordered'>
				<thead>
					<tr>
						<th>No</th>
						<th>Judul</th>
						<th>Tanggal Masuk</th>
						<th>Aksi</th>
					</tr>
				</thead>";
		$modelbuku = new MBuku();
		$query_list = $modelbuku->getData();
		$no=1;
			while($row=mysqli_fetch_array($query_list)){
			$data.=
					'<tr>
						<td>'.$no++.'</td>
						<td>'. $row['judul_buku'].'</td>
						<td>'. $row['tanggal_buku_masuk'].'</td>
						<td><a name="detail" value="detail" class="btn btn-info btn-xs" href="detail.php?id_buku='.$row['id_buku'].'">Detail</a>
							<a class="btn btn-warning btn-xs" name="editdata" value="edit data" href="edit.php?id_buku='.$row['id_buku'].'">Edit</a>
							<a class="btn btn-danger btn-xs" name="hapusdata" value="hapus data" href="HapusData.php?id_buku='.$row['id_buku'].'">Hapus</a>
						</td>
					</tr>';
			}
		$data.='</table>';
		require('VBuku/VDataBuku.php');
	}
	
	public function detail($id_buku){
		$modelbuku = new MBuku();
		$query_list = $modelbuku->detail($id_buku);
		$row= mysqli_fetch_array($query_list);
		
		$tabel="<table class='table table-bordered'>
				<thead>
					<tr>
						<th>Id</th>
						<th>Judul</th>
						<th>Tanggal Masuk</th>
						<th>Pengarang</th>
						<th>Tahun Terbit</th>
						<th>Penerbit</th>
						<th>Kota Terbit</th>
						<th>Genre Buku</th>
						<th>Jenis Buku</th>
						<th>Deskripsi</th>
						<th>Status Buku</th>
					</tr>";
			$tabel.=
				"<tr><td>". $row['id_buku']."</td>
					<td>". $row['judul_buku']."</td>
					<td>". $row['tanggal_buku_masuk']."</td>
					<td>". $row['pengarang']."</td>
					<td>". $row['tahun_terbit']."</td>
					<td>". $row['penerbit']."</td>
					<td>". $row['kota_terbit']."</td>
					<td>". $row['genre_buku']."</td>
					<td>". $row['jenis_buku']."</td>
					<td>". $row['deskripsi']."</td>
					<td>". $row['status_buku']."</td>
				</tr></table>";
		require('VBuku/VDetail.php');
	}
	
	public function input(){
		if(!isset($_POST['submit_button'])){
			include('form.php');
			$form = new Form();
			$form->inputForm();
		}
		else{
			$this->id_buku=$_POST['id_buku'];
			$this->tanggal_buku_masuk=$_POST['tanggal_buku_masuk'];
			$this->judul_buku=$_POST['judul_buku'];
			$this->pengarang=$_POST['pengarang'];
			$this->tahun_terbit=$_POST['tahun_terbit'];
			$this->penerbit=$_POST['penerbit'];
			$this->kota_terbit=$_POST['kota_terbit'];
			$this->genre_buku=$_POST['genre_buku'];
			$this->jenis_buku=$_POST['jenis_buku'];
			$this->deskripsi=$_POST['deskripsi'];
			$this->status_buku=$_POST['status_buku'];
			
			$mbuku = new MBuku();
			$mbuku->input($this);
			$this->cetakDataBuku();
		}
	}
	
	public function edit($id_buku){
		
		if(!isset($_POST['edit_button'])){
			include('formEdit.php');
			$form = new FormEdit();
			$form->editForm();
		}
		else{
			$this->id_buku=$_POST['id_buku'];
			$this->tanggal_buku_masuk=$_POST['tanggal_buku_masuk'];
			$this->judul_buku=$_POST['judul_buku'];
			$this->pengarang=$_POST['pengarang'];
			$this->tahun_terbit=$_POST['tahun_terbit'];
			$this->penerbit=$_POST['penerbit'];
			$this->kota_terbit=$_POST['kota_terbit'];
			$this->genre_buku=$_POST['genre_buku'];
			$this->jenis_buku=$_POST['jenis_buku'];
			$this->deskripsi=$_POST['deskripsi'];
			$this->status_buku=$_POST['status_buku'];
			
			$mbuku = new MBuku();
			$mbuku->edit($this);
			$this->cetakDataBuku();
		}
	}
	
	public function hapus($id_buku){
		
		$hapusbuku = new MBuku();
		$query_list = $hapusbuku->detail($id_buku);
		$row= mysqli_fetch_array($query_list);
		$mbuku = new MBuku();
		$mbuku->hapus($id_buku);
}
}
?>