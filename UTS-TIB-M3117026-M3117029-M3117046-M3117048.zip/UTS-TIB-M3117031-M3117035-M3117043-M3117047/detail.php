<?php 
include('CPerpustakaan.php');
$buku = new CBuku();

?>
<html>
<head>
<title>Index</title>
</head>
<body>
<h1>Detail Data Buku</h1>
<?php 
	$id = $_GET['id_buku'];
	$buku->detail($id);
?>
</body>
</html>