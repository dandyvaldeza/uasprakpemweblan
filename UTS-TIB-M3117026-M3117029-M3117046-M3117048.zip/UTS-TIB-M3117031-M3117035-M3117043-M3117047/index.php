<?php
require 'CPerpustakaan.php';

$buku=new CBuku();
?>
<h1>Data Buku Perpustakaan</h1>
<nav class='navbar navbar-default'>
<div class='container'>
	<ul class='nav navbar-nav'>	
		<li><a href='index.php'><h5>Home</h5></a></li>
		<li><a href='index.php?target=input'><h5>Input Data</h5></a></li>
	</ul>
</div>
</nav>
<?php
if(!isset($_GET['target'])){
	$buku->cetakDataBuku();
}
elseif($_GET['target']=='input'){
	$buku->input();
}

?>