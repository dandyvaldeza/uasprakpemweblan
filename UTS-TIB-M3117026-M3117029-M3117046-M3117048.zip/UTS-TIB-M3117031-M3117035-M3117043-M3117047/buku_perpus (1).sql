-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 18 Apr 2019 pada 18.12
-- Versi Server: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buku_perpus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id_buku` varchar(10) NOT NULL,
  `tanggal_buku_masuk` date NOT NULL,
  `judul_buku` varchar(50) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `tahun_terbit` year(4) NOT NULL,
  `penerbit` varchar(50) NOT NULL,
  `kota_terbit` varchar(30) NOT NULL,
  `genre_buku` varchar(30) NOT NULL,
  `jenis_buku` varchar(20) NOT NULL,
  `deskripsi` text NOT NULL,
  `status_buku` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id_buku`, `tanggal_buku_masuk`, `judul_buku`, `pengarang`, `tahun_terbit`, `penerbit`, `kota_terbit`, `genre_buku`, `jenis_buku`, `deskripsi`, `status_buku`) VALUES
('BK01', '2019-04-12', 'Saksikan bahwa Aku Seorang Muslim', 'Salim A. Fillah', 2007, 'Pro-U Media', 'Jogjakarta', 'Religi', 'Lokal', 'Buku ini menceritakan tentang kebesaran Allah SWT melalui kisah-kisah pada jaman dahulu.', 'Ada'),
('BK02', '2019-04-13', 'Taking The TOEIC', 'Wendi Shin', 2013, 'Compass', 'Solo', 'Fantasy', 'Lokal', 'buku ini berisi soal soal mengenai toeic', 'Ada'),
('BK04', '2019-04-14', 'Udah Putusin Aja!', 'Felix Y. Siauw', 2013, 'CV Kekata Group', 'Jakarta', 'Horror', 'Lokal', 'aaa', 'Tersedia');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
