<?php 
include('CPerpustakaan.php');
$buku = new CBuku();

?>
<html>
<head>
<title>Index</title>
</head>
<body>
<?php 
	$id = $_GET['id_buku'];
	$buku->edit($id);
	if((isset($_POST['edit']))){
		$buku->edit($id);
		print "<script>location='IndexBukuPerpus.php';</script>";
	}
?>
</body>
</html>