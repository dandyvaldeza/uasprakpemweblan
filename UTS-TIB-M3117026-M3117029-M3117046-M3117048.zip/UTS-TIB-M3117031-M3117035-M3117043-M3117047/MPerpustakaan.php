<?php
class MBuku{
	var $host="localhost";
	var $user="root";
	var $pass="";
	var $db="buku_perpus"; 
	 
	public function koneksi(){
		return $con=mysqli_connect($this->host,$this->user,$this->pass,$this->db);
	}
	public function getData()
	{
		$con=$this->koneksi();
		$query="SELECT * FROM buku";
		$query_list = mysqli_query($con,$query);
		return $query_list;
	}
	public function detail($id_buku)
	{
		$con=$this->koneksi();
		$query="SELECT * FROM buku WHERE id_buku = '$id_buku'";
		$query_list = mysqli_query($con,$query);
		return $query_list;
	}
	public function input($buku){
		$con=$this->koneksi();
		$query_list= mysqli_query($con,"INSERT INTO buku (id_buku,
										tanggal_buku_masuk,judul_buku,
										pengarang,tahun_terbit,
										penerbit,kota_terbit,genre_buku,jenis_buku, deskripsi,
										status_buku) VALUES 
										('".$buku->id_buku."','".$buku->tanggal_buku_masuk."',
										'".$buku->judul_buku."','".$buku->pengarang."',
										'".$buku->tahun_terbit."','".$buku->penerbit."','".$buku->kota_terbit."',
										'".$buku->genre_buku."','".$buku->jenis_buku."',
										'".$buku->deskripsi."','".$buku->status_buku."')");
		return $query_list;
	}
	public function edit($buku){
		$koneksi=$this->koneksi();
		$query_list= mysqli_query($koneksi,"UPDATE buku SET id_buku 
									='".$buku->id_buku."',tanggal_buku_masuk ='".$buku->tanggal_buku_masuk
									."',judul_buku ='".$buku->judul_buku."',pengarang ='".$buku->pengarang
									."',tahun_terbit='".$buku->tahun_terbit."',penerbit ='".$buku->penerbit
									."',kota_terbit ='".$buku->kota_terbit."',genre_buku ='".$buku->genre_buku
									."',jenis_buku ='".$buku->jenis_buku
									."',deskripsi ='".$buku->deskripsi."' WHERE buku.id_buku='".$buku->id_buku."'");
		return $query_list;
	}
	public function hapus($id_buku){
		$con=$this->koneksi();
		$query_list= mysqli_query($con,"DELETE FROM buku WHERE id_buku = '$id_buku'");
		return $query_list;
	}
}
?>